"use client";

import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import {
  AudioWaveform,
  Database,
  Download,
  Dumbbell,
  Flame,
  Footprints,
  Leaf,
  Loader,
  Play,
  Rocket,
  Sparkles,
  Sprout,
  Square,
  Waves,
  Zap,
  type LucideIcon,
} from "lucide-react";
import {
  DURATIONS,
  FREQUENCIES,
  GENRES,
  GOALS,
  LEVELS,
  VOICES,
  type Phase,
  type WorkoutScenario,
} from "@/lib/scenario";
import SectionHead from "./SectionHead";

const GOAL_ICONS: Record<string, LucideIcon> = {
  Похудение: Flame,
  Сила: Dumbbell,
  Выносливость: Footprints,
  Восстановление: Leaf,
  "Общая форма": Zap,
};

const LEVEL_ICONS: Record<string, LucideIcon> = {
  Новичок: Sprout,
  Средний: Zap,
  Продвинутый: Rocket,
};

const PHASE_ICONS: Record<Phase["key"], LucideIcon> = {
  warmup: Waves,
  activation: Zap,
  main: Flame,
  cooldown: Leaf,
};

const PHASE_TILES: Record<Phase["key"], string> = {
  warmup: "bg-pine/10 text-pine",
  activation: "bg-ember/10 text-ember",
  main: "bg-grape/10 text-grape",
  cooldown: "bg-teal/10 text-teal",
};

const LOADING_STEPS = [
  "Анализируем параметры…",
  "Строим фазы тренировки…",
  "Подбираем BPM и жанры…",
  "Пишем реплики коуча…",
  "Сохраняем сценарий в базу…",
];

interface GenerateResponse {
  scenario: WorkoutScenario;
  serial: number | null;
  persisted: boolean;
  error?: string;
}

interface SketchHandle {
  stop: () => void;
}

// Generative WebAudio sketch — a small synth loop tuned to the workout's BPM.
function createSketch(bpm: number): SketchHandle {
  const AC =
    window.AudioContext ??
    (window as unknown as { webkitAudioContext: typeof AudioContext })
      .webkitAudioContext;
  const ctx = new AC();
  void ctx.resume();

  const master = ctx.createGain();
  master.gain.value = 0;
  const comp = ctx.createDynamicsCompressor();
  master.connect(comp);
  comp.connect(ctx.destination);
  master.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 0.7);

  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 340;
  filter.Q.value = 5;
  const padGain = ctx.createGain();
  padGain.gain.value = 0.32;
  filter.connect(padGain);
  padGain.connect(master);

  const oscs: OscillatorNode[] = [];
  [110, 165].forEach((freq, i) => {
    const osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.value = freq;
    osc.detune.value = i === 0 ? -7 : 7;
    osc.connect(filter);
    osc.start();
    oscs.push(osc);
  });

  const lfo = ctx.createOscillator();
  lfo.frequency.value = 0.09;
  const lfoGain = ctx.createGain();
  lfoGain.gain.value = 150;
  lfo.connect(lfoGain);
  lfoGain.connect(filter.frequency);
  lfo.start();
  oscs.push(lfo);

  const SCALE = [220, 261.63, 293.66, 329.63, 392, 440];
  const PATTERN = [1, 0, 0, 1, 0, 1, 0, 0];
  let step = 0;
  const stepMs = (60 / bpm / 2) * 1000;

  const kick = (when: number) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(150, when);
    osc.frequency.exponentialRampToValueAtTime(42, when + 0.22);
    gain.gain.setValueAtTime(0.5, when);
    gain.gain.exponentialRampToValueAtTime(0.001, when + 0.26);
    osc.connect(gain);
    gain.connect(master);
    osc.start(when);
    osc.stop(when + 0.3);
  };

  const pluck = (when: number, freq: number) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const hp = ctx.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 320;
    osc.type = "triangle";
    osc.frequency.value = freq * 2;
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(0.2, when + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, when + 0.34);
    osc.connect(hp);
    hp.connect(gain);
    gain.connect(master);
    osc.start(when);
    osc.stop(when + 0.4);
  };

  const timer = window.setInterval(() => {
    const when = ctx.currentTime + 0.06;
    if (step % 4 === 0) kick(when);
    if (PATTERN[step % PATTERN.length] === 1) {
      pluck(when, SCALE[(step * 3) % SCALE.length]);
    }
    step++;
  }, stepMs);

  return {
    stop: () => {
      window.clearInterval(timer);
      const now = ctx.currentTime;
      master.gain.cancelScheduledValues(now);
      master.gain.setValueAtTime(Math.max(master.gain.value, 0.0001), now);
      master.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);
      window.setTimeout(() => {
        oscs.forEach((osc) => {
          try {
            osc.stop();
          } catch {
            // oscillator already stopped
          }
        });
        void ctx.close();
      }, 480);
    },
  };
}

function Eq({ paused }: { paused?: boolean }) {
  return (
    <span className={`eq ${paused ? "eq-paused" : ""}`} aria-hidden="true">
      <i />
      <i />
      <i />
      <i />
      <i />
    </span>
  );
}

type Status = "idle" | "loading" | "done";

export default function Demo() {
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState("");
  const [scenario, setScenario] = useState<WorkoutScenario | null>(null);
  const [serial, setSerial] = useState<number | null>(null);
  const [persisted, setPersisted] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);

  const sketchRef = useRef<SketchHandle | null>(null);

  const stopSketch = useCallback(() => {
    sketchRef.current?.stop();
    sketchRef.current = null;
    setPlaying(false);
  }, []);

  useEffect(() => stopSketch, [stopSketch]);

  useEffect(() => {
    if (status !== "loading") return;
    setLoadingStep(0);
    const timer = window.setInterval(
      () => setLoadingStep((s) => (s + 1) % LOADING_STEPS.length),
      420,
    );
    return () => window.clearInterval(timer);
  }, [status]);

  const mainBpm = scenario
    ? Math.round(
        scenario.phases.reduce(
          (acc, phase) => acc + (phase.bpm[0] + phase.bpm[1]) / 2,
          0,
        ) / scenario.phases.length,
      )
    : 120;

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");

    const data = new FormData(event.currentTarget);
    const payload = {
      goal: String(data.get("goal") ?? ""),
      duration: Number(data.get("duration")),
      level: String(data.get("level") ?? ""),
      genres: data.getAll("genres").map(String),
      voice: String(data.get("voice") ?? ""),
      frequency: Number(data.get("frequency")),
    };

    if (payload.genres.length === 0) {
      setError("Выбери хотя бы один музыкальный жанр.");
      return;
    }

    stopSketch();
    setStatus("loading");
    const started = Date.now();

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as GenerateResponse;

      if (!res.ok) {
        throw new Error(json.error ?? "Не удалось собрать сценарий.");
      }

      // Keep the loader visible long enough to feel deliberate.
      const elapsed = Date.now() - started;
      if (elapsed < 1600) {
        await new Promise((resolve) => setTimeout(resolve, 1600 - elapsed));
      }

      setScenario(json.scenario);
      setSerial(json.serial);
      setPersisted(json.persisted);
      setStatus("done");
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Не удалось собрать сценарий.",
      );
      setStatus("idle");
    }
  }

  function togglePlayback() {
    if (!scenario) return;
    if (playing) {
      stopSketch();
      return;
    }
    try {
      sketchRef.current = createSketch(mainBpm);
      setPlaying(true);
    } catch {
      setError("Твой браузер не поддерживает Web Audio API.");
    }
  }

  function downloadJson() {
    if (!scenario) return;
    const blob = new Blob([JSON.stringify(scenario, null, 2)], {
      type: "application/json;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "ai-audio-coach-workout.json";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <section id="demo" className="relative overflow-hidden py-24 md:py-32">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(900px_480px_at_15%_20%,rgba(14,107,77,0.07),transparent_60%),radial-gradient(800px_500px_at_90%_80%,rgba(93,67,184,0.08),transparent_60%)]"
      />
      <span
        aria-hidden="true"
        className="watermark pointer-events-none absolute right-0 top-10 hidden font-display text-[10rem] font-extrabold leading-none lg:block"
      >
        DEMO
      </span>

      <div className="wrap relative">
        <SectionHead
          num="05"
          kicker="Интерактивное демо"
          title={
            <>
              Собери свою <span className="gradient-text">аудиотренировку</span>
            </>
          }
          sub="Выбери настройки — прототип построит фазы, BPM и реплики коуча и сохранит сценарий в базу данных."
        />

        <div className="mt-12 grid items-start gap-6 lg:grid-cols-[0.92fr_1.08fr]">
          {/* ---------- form ---------- */}
          <form
            onSubmit={handleSubmit}
            onChange={() => setError("")}
            className="card rounded-[28px] p-6 md:p-8"
            noValidate
          >
            <fieldset>
              <legend className="text-sm font-bold text-ink">
                <span className="mr-2 font-mono text-xs text-pine">01</span>
                Твоя цель
              </legend>
              <div className="mt-4 flex flex-wrap gap-2" role="radiogroup" aria-label="Цель тренировки">
                {GOALS.map((goal, i) => {
                  const Icon = GOAL_ICONS[goal];
                  return (
                    <label key={goal} className="cursor-pointer">
                      <input
                        type="radio"
                        name="goal"
                        value={goal}
                        defaultChecked={i === 0}
                        className="peer sr-only"
                      />
                      <span className="flex items-center gap-2 rounded-full border border-ink/12 bg-white/60 px-4 py-2.5 text-[0.83rem] font-semibold text-umber transition-all duration-300 hover:border-ink/35 hover:text-ink peer-checked:border-pine/60 peer-checked:bg-pine/10 peer-checked:text-pine peer-checked:shadow-[0_6px_20px_rgba(14,107,77,0.15)]">
                        <Icon className="size-4" />
                        {goal}
                      </span>
                    </label>
                  );
                })}
              </div>
            </fieldset>

            <fieldset className="mt-7">
              <legend className="text-sm font-bold text-ink">
                <span className="mr-2 font-mono text-xs text-pine">02</span>
                Длительность
              </legend>
              <div className="mt-4 flex flex-wrap gap-2" role="radiogroup" aria-label="Длительность тренировки">
                {DURATIONS.map((duration) => (
                  <label key={duration} className="cursor-pointer">
                    <input
                      type="radio"
                      name="duration"
                      value={duration}
                      defaultChecked={duration === 30}
                      className="peer sr-only"
                    />
                    <span className="flex items-center rounded-full border border-ink/12 bg-white/60 px-5 py-2.5 font-mono text-[0.83rem] font-semibold text-umber transition-all duration-300 hover:border-ink/35 hover:text-ink peer-checked:border-pine/60 peer-checked:bg-pine/10 peer-checked:text-pine">
                      {duration} мин
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>

            <fieldset className="mt-7">
              <legend className="text-sm font-bold text-ink">
                <span className="mr-2 font-mono text-xs text-pine">03</span>
                Уровень подготовки
              </legend>
              <div className="mt-4 flex flex-wrap gap-2" role="radiogroup" aria-label="Уровень подготовки">
                {LEVELS.map((level, i) => {
                  const Icon = LEVEL_ICONS[level];
                  return (
                    <label key={level} className="cursor-pointer">
                      <input
                        type="radio"
                        name="level"
                        value={level}
                        defaultChecked={i === 0}
                        className="peer sr-only"
                      />
                      <span className="flex items-center gap-2 rounded-full border border-ink/12 bg-white/60 px-4 py-2.5 text-[0.83rem] font-semibold text-umber transition-all duration-300 hover:border-ink/35 hover:text-ink peer-checked:border-pine/60 peer-checked:bg-pine/10 peer-checked:text-pine">
                        <Icon className="size-4" />
                        {level}
                      </span>
                    </label>
                  );
                })}
              </div>
            </fieldset>

            <fieldset className="mt-7">
              <legend className="text-sm font-bold text-ink">
                <span className="mr-2 font-mono text-xs text-pine">04</span>
                Жанры музыки{" "}
                <span className="font-normal text-faint">(можно несколько)</span>
              </legend>
              <div className="mt-4 flex flex-wrap gap-2">
                {GENRES.map((genre) => (
                  <label key={genre} className="cursor-pointer">
                    <input
                      type="checkbox"
                      name="genres"
                      value={genre}
                      defaultChecked={genre === "Pop" || genre === "Electronic"}
                      className="peer sr-only"
                    />
                    <span className="flex items-center gap-2 rounded-full border border-ink/12 bg-white/60 px-4 py-2.5 text-[0.83rem] font-semibold text-umber transition-all duration-300 hover:border-ink/35 hover:text-ink peer-checked:border-grape/60 peer-checked:bg-grape/10 peer-checked:text-grape">
                      {genre}
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>

            <div className="mt-7 grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="voice" className="text-sm font-bold text-ink">
                  <span className="mr-2 font-mono text-xs text-pine">05</span>
                  Голос коуча
                </label>
                <select
                  id="voice"
                  name="voice"
                  className="select-dark mt-3 w-full rounded-2xl border border-ink/12 bg-white/60 px-4 py-3.5 text-sm text-ink outline-none transition-colors focus:border-pine/50"
                >
                  {VOICES.map((voice) => (
                    <option key={voice} value={voice}>
                      {voice}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="frequency" className="text-sm font-bold text-ink">
                  <span className="mr-2 font-mono text-xs text-pine">06</span>
                  Частота подсказок
                </label>
                <select
                  id="frequency"
                  name="frequency"
                  className="select-dark mt-3 w-full rounded-2xl border border-ink/12 bg-white/60 px-4 py-3.5 text-sm text-ink outline-none transition-colors focus:border-pine/50"
                >
                  {FREQUENCIES.map((frequency) => (
                    <option key={frequency} value={frequency}>
                      Каждые {frequency} минуты
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <p className="mt-6 min-h-5 text-sm text-[#b4443c]" role="alert">
              {error}
            </p>

            <button
              type="submit"
              disabled={status === "loading"}
              className="btn-shine mt-2 inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-ink py-4 text-sm font-extrabold text-cream transition-all duration-300 enabled:hover:-translate-y-0.5 enabled:hover:shadow-[0_16px_40px_rgba(27,23,18,0.3)] disabled:cursor-wait disabled:opacity-60"
            >
              {status === "loading" ? (
                <>
                  <Loader className="size-4 animate-spin" />
                  Собираем сценарий…
                </>
              ) : (
                <>
                  <Sparkles className="size-4" />
                  Сгенерировать тренировку
                </>
              )}
            </button>
            <p className="mt-3.5 text-center text-[0.72rem] text-faint">
              Сценарий генерируется на сервере и сохраняется в PostgreSQL.
            </p>
          </form>

          {/* ---------- result ---------- */}
          <div
            className="card min-h-[560px] rounded-[28px] p-6 md:p-8"
            aria-live="polite"
            aria-atomic="true"
          >
            {status === "idle" && (
              <div className="grid min-h-[496px] place-items-center text-center">
                <div>
                  <span className="mx-auto grid size-20 place-items-center rounded-full border border-dashed border-pine/40 bg-pine/[0.06]">
                    <Waves className="size-8 text-pine" />
                  </span>
                  <h3 className="mt-7 font-display text-lg font-semibold">
                    Твоя тренировка начинается здесь
                  </h3>
                  <p className="mx-auto mt-3 max-w-sm text-sm leading-relaxed text-umber">
                    Заполни параметры слева и нажми «Сгенерировать тренировку» —
                    здесь появится персональный сценарий с фазами, BPM и
                    репликами коуча.
                  </p>
                </div>
              </div>
            )}

            {status === "loading" && (
              <div className="grid min-h-[496px] place-items-center text-center">
                <div>
                  <span className="relative mx-auto grid size-24 place-items-center">
                    <span className="absolute inset-0 animate-[spin-slow_2.2s_linear_infinite] rounded-full border-2 border-dashed border-pine/50" />
                    <span className="absolute inset-2 animate-[spin-slow_3.4s_linear_infinite_reverse] rounded-full border border-grape/40" />
                    <AudioWaveform className="size-8 animate-pulse text-pine" />
                  </span>
                  <h3 className="mt-8 font-display text-base font-semibold">
                    Собираем твой сценарий…
                  </h3>
                  <p className="mt-3 h-5 text-sm text-pine/90 transition-all">
                    {LOADING_STEPS[loadingStep]}
                  </p>
                </div>
              </div>
            )}

            {status === "done" && scenario && (
              <div>
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-ink/10 pb-6">
                  <div>
                    <h3 className="font-display text-lg font-bold">
                      Твоя аудиотренировка{" "}
                      <span className="gradient-text">готова</span>
                    </h3>
                    <p className="mt-1.5 text-sm text-umber">
                      {scenario.duration} минут · {scenario.goal} ·{" "}
                      {scenario.level} уровень · {scenario.genres.join(" + ")}
                    </p>
                  </div>
                  <span className="inline-flex items-center gap-2 rounded-full border border-pine/35 bg-pine/[0.08] px-3.5 py-2 text-[0.72rem] font-bold text-pine">
                    <span className="halo-dot size-1.5 rounded-full bg-pine" />
                    {persisted && serial !== null ? (
                      <>
                        <Database className="size-3.5" />
                        Сценарий № {String(serial).padStart(4, "0")} в базе
                      </>
                    ) : (
                      "Локальный сценарий"
                    )}
                  </span>
                </div>

                <div className="divide-y divide-ink/8">
                  {scenario.phases.map((phase) => {
                    const Icon = PHASE_ICONS[phase.key];
                    return (
                      <article
                        key={phase.key}
                        className="grid grid-cols-[44px_1fr] gap-4 py-5"
                      >
                        <span
                          className={`grid size-11 place-items-center rounded-2xl ${PHASE_TILES[phase.key]}`}
                        >
                          <Icon className="size-5" strokeWidth={2} />
                        </span>
                        <div>
                          <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                            <h4 className="text-[0.95rem] font-bold">
                              {phase.name}{" "}
                              <span className="font-mono text-xs font-medium text-faint">
                                {phase.start}–{phase.end} мин
                              </span>
                            </h4>
                            <span className="font-mono text-[0.72rem] font-semibold tracking-wide text-pine">
                              BPM {phase.bpm[0]}–{phase.bpm[1]} · {phase.tone}
                            </span>
                          </div>
                          <p className="mt-1.5 text-[0.83rem] leading-relaxed text-umber">
                            «{phase.cue}»
                          </p>
                        </div>
                      </article>
                    );
                  })}
                </div>

                <div className="mt-5 flex flex-col gap-3 sm:flex-row">
                  <button
                    type="button"
                    onClick={togglePlayback}
                    className="inline-flex flex-1 items-center justify-center gap-2.5 rounded-full border border-ink/15 bg-white/60 py-3.5 text-sm font-bold text-ink transition-all duration-300 hover:border-pine/50 hover:bg-white/90"
                  >
                    {playing ? (
                      <>
                        <Square className="size-4 text-pine" />
                        Остановить
                      </>
                    ) : (
                      <>
                        <Play className="size-4 text-pine" />
                        Слушать скетч
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={downloadJson}
                    className="btn-shine inline-flex flex-1 items-center justify-center gap-2.5 rounded-full bg-ink py-3.5 text-sm font-extrabold text-cream transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_14px_36px_rgba(27,23,18,0.28)]"
                  >
                    <Download className="size-4" />
                    Скачать сценарий
                  </button>
                </div>

                <div
                  className={`mt-4 items-center gap-3 rounded-2xl border border-ink/10 bg-white/60 px-4 py-3 text-[0.8rem] text-umber ${
                    playing ? "flex" : "hidden"
                  }`}
                  role="status"
                >
                  <Eq paused={!playing} />
                  <span>
                    Играет генеративный аудио-скетч · средний темп сценария{" "}
                    <b className="font-mono text-pine">{mainBpm} BPM</b>
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

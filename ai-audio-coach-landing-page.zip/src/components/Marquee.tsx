import { AudioWaveform } from "lucide-react";

const ITEMS = [
  "Персональный сценарий",
  "Музыка под BPM",
  "Голосовой коуч",
  "Факты без мифов",
  "20–60 минут",
  "Без оборудования",
];

function Row({ hidden }: { hidden?: boolean }) {
  return (
    <div className="marquee-track" aria-hidden={hidden}>
      {ITEMS.map((item) => (
        <span
          key={item}
          className="flex items-center gap-14 whitespace-nowrap font-display text-[0.8rem] font-semibold uppercase tracking-[0.22em] text-umber"
        >
          {item}
          <AudioWaveform className="size-4 text-pine" />
        </span>
      ))}
    </div>
  );
}

export default function Marquee() {
  return (
    <div className="marquee overflow-hidden border-y border-ink/10 bg-white/50 py-5">
      <div className="flex">
        <Row />
        <Row hidden />
      </div>
    </div>
  );
}

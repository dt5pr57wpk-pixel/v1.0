import { ArrowDown, Headphones } from "lucide-react";
import AudioOrb from "./AudioOrb";
import Reveal from "./Reveal";

const STATS = [
  { value: "4 фазы", label: "структуры сценария" },
  { value: "BPM 80–150", label: "темп под нагрузку" },
  { value: "0 камер", label: "только телефон и звук" },
];

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pb-14 pt-[136px] md:pt-[152px]">
      {/* decorative orbit rings */}
      <div
        aria-hidden="true"
        className="spin-slower pointer-events-none absolute -right-40 top-10 size-[560px] rounded-full border border-dashed border-grape/20"
      />
      <div
        aria-hidden="true"
        className="spin-slow-reverse pointer-events-none absolute -right-24 top-24 size-[400px] rounded-full border border-teal/15"
      />
      <span
        aria-hidden="true"
        className="watermark pointer-events-none absolute -left-6 top-24 hidden font-display text-[11rem] font-extrabold leading-none xl:block"
      >
        SOUND
      </span>

      <div className="wrap relative grid items-center gap-14 lg:grid-cols-[1.08fr_0.92fr] lg:gap-6">
        <div>
          <Reveal>
            <span className="inline-flex items-center gap-2.5 rounded-full border border-pine/30 bg-pine/[0.08] px-4 py-2 text-[0.72rem] font-bold uppercase tracking-[0.16em] text-pine">
              <span className="halo-dot size-1.5 rounded-full bg-pine" />
              Умнее с каждым треком
            </span>
          </Reveal>

          <Reveal delay={90}>
            <h1 className="mt-7 font-display text-[clamp(2.2rem,6vw,4.4rem)] font-bold leading-[1.04] tracking-tight">
              Твой персональный
              <span className="gradient-text block">аудиотренер</span>
              <span className="block">
                с ИИ<span className="text-pine">.</span>
              </span>
            </h1>
          </Reveal>

          <Reveal delay={180}>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-umber md:text-lg">
              Музыка + голосовой коуч. Без камер, тренажёров и сложного
              оборудования. Только телефон и наушники.
            </p>
          </Reveal>

          <Reveal delay={260}>
            <div className="mt-9 flex flex-wrap items-center gap-3.5">
              <a
                href="#demo"
                className="btn-shine group inline-flex items-center gap-2.5 rounded-full bg-ink px-7 py-4 text-sm font-extrabold text-cream transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_16px_40px_rgba(27,23,18,0.3)]"
              >
                Собрать тренировку
                <ArrowDown className="size-4 transition-transform duration-300 group-hover:translate-y-0.5" />
              </a>
              <a
                href="#features"
                className="inline-flex items-center gap-2.5 rounded-full border border-ink/15 bg-white/60 px-7 py-4 text-sm font-bold text-ink backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:border-pine/50 hover:bg-white/90"
              >
                <Headphones className="size-4 text-pine" />
                Узнать больше
              </a>
            </div>
          </Reveal>

          <Reveal delay={340}>
            <dl className="mt-12 grid max-w-lg grid-cols-3 gap-5 border-t border-ink/10 pt-6">
              {STATS.map((stat) => (
                <div key={stat.value}>
                  <dt className="sr-only">{stat.label}</dt>
                  <dd className="font-display text-sm font-bold text-ink md:text-base">
                    {stat.value}
                  </dd>
                  <dd className="mt-1 text-[0.72rem] leading-snug text-faint">
                    {stat.label}
                  </dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>

        <Reveal delay={220} className="relative">
          <div className="relative mx-auto aspect-square w-full max-w-[520px]">
            <AudioOrb className="absolute inset-0 size-full" />

            <div className="card absolute bottom-6 left-1/2 z-10 flex -translate-x-1/2 items-center gap-3 rounded-full px-5 py-2.5">
              <span className="eq" aria-hidden="true">
                <i /><i /><i /><i /><i />
              </span>
              <span className="font-mono text-[0.72rem] font-semibold tracking-wider text-pine">
                BPM 128
              </span>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

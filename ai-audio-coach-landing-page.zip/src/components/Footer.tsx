import { ArrowUpRight, AudioWaveform } from "lucide-react";

const SOCIALS = [
  { label: "Telegram", href: "#top" },
  { label: "VK", href: "#top" },
  { label: "YouTube", href: "#top" },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-ink/10 pt-16">
      <div className="wrap relative z-10 grid gap-10 pb-14 md:grid-cols-[1.1fr_1fr]">
        <div>
          <a href="#top" className="group inline-flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-xl bg-gradient-to-br from-pine to-teal text-cream shadow-[0_8px_22px_rgba(14,107,77,0.3)] transition-transform duration-500 group-hover:rotate-12">
              <AudioWaveform className="size-5" strokeWidth={2.4} />
            </span>
            <span className="font-display text-[0.82rem] font-bold leading-[1.15] tracking-tight">
              AI AUDIO
              <span className="block text-pine">COACH</span>
            </span>
          </a>
          <p className="mt-5 max-w-xs text-sm text-umber">
            Твой путь к лучшей версии себя.
          </p>
        </div>

        <div className="flex flex-wrap items-start gap-x-8 gap-y-3 md:justify-end">
          <a
            href="mailto:hello@example.com"
            className="text-sm font-semibold text-umber transition-colors hover:text-pine"
          >
            Контакты
          </a>
          {SOCIALS.map((social) => (
            <a
              key={social.label}
              href={social.href}
              aria-label={`${social.label} (демо-ссылка)`}
              className="group inline-flex items-center gap-1 text-sm font-semibold text-umber transition-colors hover:text-pine"
            >
              {social.label}
              <ArrowUpRight className="size-3.5 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          ))}
        </div>
      </div>

      <div className="wrap relative z-10 flex flex-col gap-3 border-t border-ink/10 py-7 text-[0.74rem] leading-relaxed text-faint md:flex-row md:items-center md:justify-between">
        <span>© 2025–2026 AI Audio Coach. Концепт-прототип.</span>
        <span className="max-w-2xl">
          Данный продукт не является медицинским изделием. При боли,
          головокружении или плохом самочувствии прекрати тренировку. При
          сомнениях обратись к врачу.
        </span>
      </div>

      <div
        aria-hidden="true"
        className="watermark pointer-events-none select-none whitespace-nowrap text-center font-display text-[12.5vw] font-extrabold leading-[0.82] tracking-tight"
      >
        AUDIO COACH
      </div>
    </footer>
  );
}

import {
  Activity,
  GraduationCap,
  Headphones,
  Languages,
  ShieldCheck,
  VideoOff,
  type LucideIcon,
} from "lucide-react";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";

const PHASES = [
  { name: "Разминка", time: "0–5 мин", grow: 1, cls: "grad-warm", textCls: "text-[#06351f]" },
  { name: "Активация", time: "5–10 мин", grow: 1, cls: "grad-fire", textCls: "text-[#3a2403]" },
  { name: "Основная часть", time: "10–25 мин", grow: 3, cls: "grad-main", textCls: "text-white" },
  { name: "Заминка", time: "25–30 мин", grow: 1, cls: "grad-cool", textCls: "text-[#04283a]" },
];

const DETAILS = [
  { bpm: "BPM 90–110", note: "Спокойный тон" },
  { bpm: "BPM 110–120", note: "Мотивация" },
  { bpm: "BPM 120–140", note: "Факты и энергия" },
  { bpm: "BPM 80–90", note: "Растяжка" },
];

interface WhyItem {
  icon: LucideIcon;
  title: string;
  text: string;
}

const WHY: WhyItem[] = [
  { icon: GraduationCap, title: "Образовательный слой", text: "Факты и советы дополняют музыку." },
  { icon: VideoOff, title: "Без камер и тренажёров", text: "Достаточно телефона и наушников." },
  { icon: Headphones, title: "Свободное прослушивание", text: "Сценарий можно слушать в удобном плеере." },
  { icon: Activity, title: "Разные активности", text: "Бег, йога и домашние тренировки." },
  { icon: ShieldCheck, title: "Забота о восстановлении", text: "Напоминания о темпе и отдыхе." },
  { icon: Languages, title: "Несколько языков", text: "Возможность расширить аудиторию." },
];

export default function Phases() {
  return (
    <section id="example" className="relative py-24 md:py-28">
      <div className="wrap grid gap-16 lg:grid-cols-[1.05fr_0.95fr] lg:gap-12">
        <div>
          <SectionHead
            num="03"
            kicker="Пример тренировки"
            title={
              <>
                30 минут <span className="gradient-text">в твоём ритме</span>
              </>
            }
            sub="Пример структуры: темп и голос меняются вместе с нагрузкой. Наведи на фазу, чтобы раскрыть её."
          />

          <Reveal delay={140}>
            <div
              className="mt-10 flex h-28 overflow-hidden rounded-3xl border border-ink/15 shadow-[0_18px_44px_-22px_rgba(27,23,18,0.25)]"
              aria-label="Шкала фаз 30-минутной тренировки"
            >
              {PHASES.map((phase) => (
                <div
                  key={phase.name}
                  className={`phase-seg ${phase.cls} flex flex-col justify-center px-4 ${phase.textCls}`}
                  style={{ flexGrow: phase.grow, flexBasis: 0 }}
                >
                  <span className="truncate font-display text-[0.72rem] font-bold md:text-[0.8rem]">
                    {phase.name}
                  </span>
                  <span className="mt-1 text-[0.7rem] font-semibold opacity-75">
                    {phase.time}
                  </span>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 overflow-hidden rounded-b-3xl border border-t-0 border-ink/12 bg-white/50 md:grid-cols-4">
              {DETAILS.map((detail) => (
                <div
                  key={detail.bpm}
                  className="border-ink/12 px-4 py-4 text-sm [&:nth-child(odd)]:border-r md:[&:not(:last-child)]:border-r"
                >
                  <b className="block font-display text-[0.78rem] font-semibold text-pine">
                    {detail.bpm}
                  </b>
                  <span className="mt-1 block text-[0.78rem] text-umber">
                    {detail.note}
                  </span>
                </div>
              ))}
            </div>
          </Reveal>
        </div>

        <div>
          <SectionHead
            num="04"
            kicker="Почему это уникально"
            title={
              <>
                Больше, <span className="gradient-text">чем плейлист</span>
              </>
            }
          />
          <div className="mt-10 grid gap-3 sm:grid-cols-2">
            {WHY.map((item, index) => (
              <Reveal key={item.title} delay={index * 60}>
                <article className="card group h-full rounded-3xl p-5">
                  <span className="grid size-10 place-items-center rounded-xl bg-ink/[0.05] text-pine transition-all duration-500 group-hover:bg-pine/12 group-hover:shadow-[0_0_18px_rgba(14,107,77,0.25)]">
                    <item.icon className="size-4.5" strokeWidth={2} />
                  </span>
                  <h3 className="mt-4 text-[0.92rem] font-bold">{item.title}</h3>
                  <p className="mt-1.5 text-[0.82rem] leading-relaxed text-umber">
                    {item.text}
                  </p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

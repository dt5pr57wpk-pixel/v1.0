import Reveal from "./Reveal";
import SectionHead from "./SectionHead";

const STEPS = [
  { num: "01", title: "Выбираешь параметры", text: "Цель, длительность, уровень и предпочтения." },
  { num: "02", title: "Строится план", text: "ИИ распределяет тренировку по фазам." },
  { num: "03", title: "Подбирается музыка", text: "Темп BPM и энергия соответствуют этапу." },
  { num: "04", title: "Добавляется голос", text: "Подсказки и мотивация в выбранном стиле." },
  { num: "05", title: "Всё микшируется", text: "Музыка и голос объединяются в аудиофайл." },
  { num: "06", title: "Тренируешься", text: "Слушаешь и двигаешься в своём ритме." },
];

export default function Steps() {
  return (
    <section id="how" className="relative py-24 md:py-28">
      <div className="wrap">
        <SectionHead
          num="02"
          kicker="Как это работает"
          title={
            <>
              От цели до готового аудио —{" "}
              <span className="gradient-text">6 шагов</span>
            </>
          }
          sub="Сценарий собирается вокруг твоей тренировки, а не наоборот."
        />

        <div className="mt-14 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-6">
          {STEPS.map((step, index) => (
            <Reveal key={step.num} delay={index * 80}>
              <article className="group relative border-t border-ink/15 pt-7 transition-colors duration-500 hover:border-pine/60">
                <span className="absolute -top-[5px] left-0 size-2 rounded-full bg-faint/60 transition-all duration-500 group-hover:bg-pine group-hover:shadow-[0_0_14px_rgba(14,107,77,0.7)]" />
                <span className="text-outline font-display text-[2.6rem] font-extrabold leading-none transition-all duration-500 group-hover:[-webkit-text-stroke-color:rgba(14,107,77,0.75)]">
                  {step.num}
                </span>
                <h3 className="mt-5 font-display text-[0.88rem] font-semibold leading-snug">
                  {step.title}
                </h3>
                <p className="mt-2 text-[0.83rem] leading-relaxed text-umber">
                  {step.text}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

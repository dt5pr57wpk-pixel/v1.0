"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import SectionHead from "./SectionHead";

const ITEMS = [
  {
    q: "Нужны ли камеры или тренажёры?",
    a: "Нет. Для базового сценария достаточно телефона и наушников. Дополнительные датчики могут появиться в будущих версиях.",
  },
  {
    q: "Работает ли это со Spotify и Яндекс Музыкой?",
    a: "Да, интеграции в разработке: сценарий сможет подтягивать твои треки из Spotify и Яндекс Музыки, подбирая их по BPM каждой фазы. В текущем прототипе доступен экспорт сценария в JSON.",
  },
  {
    q: "Это заменяет тренера?",
    a: "Нет. Это цифровой помощник для мотивации и организации занятий, а не замена персональному тренеру или медицинскому специалисту.",
  },
  {
    q: "Безопасно ли это?",
    a: "Сценарии должны учитывать ограничения и восстановление, но приложение не может гарантировать безопасность. Выбирай нагрузку по самочувствию и проконсультируйся с врачом при наличии медицинских противопоказаний.",
  },
  {
    q: "Сколько стоит?",
    a: "Предварительная гипотеза для подписки — 299–499 ₽ в месяц. Это ориентир бизнес-модели, а не действующий тариф.",
  },
];

export default function Faq() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-24 md:py-28">
      <div className="wrap grid gap-12 lg:grid-cols-[0.85fr_1.15fr]">
        <div>
          <SectionHead
            num="08"
            kicker="FAQ"
            title={
              <>
                Частые <span className="gradient-text">вопросы</span>
              </>
            }
            sub="Коротко о том, как устроен аудиокоуч."
          />
        </div>

        <div className="flex flex-col gap-3">
          {ITEMS.map((item, index) => {
            const open = openIndex === index;
            return (
              <div
                key={item.q}
                className={`card rounded-2xl transition-all duration-500 ${
                  open ? "border-pine/40" : ""
                }`}
              >
                <button
                  type="button"
                  className="flex w-full items-center justify-between gap-5 px-6 py-5 text-left"
                  aria-expanded={open}
                  aria-controls={`faq-answer-${index}`}
                  onClick={() => setOpenIndex(open ? null : index)}
                >
                  <span className="font-display text-[0.9rem] font-semibold leading-snug">
                    {item.q}
                  </span>
                  <span
                    className={`grid size-8 shrink-0 place-items-center rounded-full border transition-all duration-400 ${
                      open
                        ? "rotate-45 border-pine/60 bg-pine/10 text-pine"
                        : "border-ink/15 text-umber"
                    }`}
                  >
                    <Plus className="size-4" />
                  </span>
                </button>
                <div
                  id={`faq-answer-${index}`}
                  className="grid transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]"
                  style={{ gridTemplateRows: open ? "1fr" : "0fr" }}
                >
                  <div className="min-h-0 overflow-hidden">
                    <p className="px-6 pb-6 text-sm leading-relaxed text-umber">
                      {item.a}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

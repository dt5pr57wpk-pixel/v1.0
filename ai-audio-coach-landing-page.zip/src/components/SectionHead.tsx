import type { ReactNode } from "react";
import Reveal from "./Reveal";

interface SectionHeadProps {
  num: string;
  kicker: string;
  title: ReactNode;
  sub?: string;
  align?: "left" | "center";
}

export default function SectionHead({
  num,
  kicker,
  title,
  sub,
  align = "left",
}: SectionHeadProps) {
  return (
    <Reveal className={align === "center" ? "text-center" : ""}>
      <div
        className={`flex items-center gap-4 ${
          align === "center" ? "justify-center" : ""
        }`}
      >
        <span className="font-mono text-xs font-semibold tracking-widest text-pine">
          /{num}
        </span>
        <span className="text-[0.7rem] font-extrabold uppercase tracking-[0.22em] text-faint">
          {kicker}
        </span>
        <span
          className={`h-px flex-1 bg-gradient-to-r from-ink/15 to-transparent ${
            align === "center" ? "hidden" : ""
          }`}
        />
      </div>
      <h2 className="mt-5 max-w-3xl font-display text-[clamp(1.7rem,3.6vw,2.7rem)] font-bold leading-[1.13] tracking-tight">
        {title}
      </h2>
      {sub ? (
        <p
          className={`mt-4 max-w-xl leading-relaxed text-umber ${
            align === "center" ? "mx-auto" : ""
          }`}
        >
          {sub}
        </p>
      ) : null}
    </Reveal>
  );
}

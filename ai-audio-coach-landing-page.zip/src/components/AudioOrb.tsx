"use client";

import { useEffect, useRef } from "react";

interface Point3 {
  x: number;
  y: number;
  z: number;
  hue: number;
  size: number;
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

// Pine (14,107,77) -> Teal (15,110,132) -> Grape (93,67,184) — tuned for a
// light paper background.
function colorAt(t: number, alpha: number) {
  let r: number, g: number, b: number;
  if (t < 0.5) {
    const k = t / 0.5;
    r = lerp(14, 15, k);
    g = lerp(107, 110, k);
    b = lerp(77, 132, k);
  } else {
    const k = (t - 0.5) / 0.5;
    r = lerp(15, 93, k);
    g = lerp(110, 67, k);
    b = lerp(132, 184, k);
  }
  return `rgba(${r | 0},${g | 0},${b | 0},${alpha})`;
}

export default function AudioOrb({ className }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    let width = 0;
    let height = 0;
    let raf = 0;
    let running = true;

    // Fibonacci sphere
    const N = 640;
    const points: Point3[] = [];
    const golden = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < N; i++) {
      const y = 1 - (i / (N - 1)) * 2;
      const radiusAtY = Math.sqrt(1 - y * y);
      const theta = golden * i;
      points.push({
        x: Math.cos(theta) * radiusAtY,
        y,
        z: Math.sin(theta) * radiusAtY,
        hue: (i * 0.618) % 1,
        size: 0.7 + ((i * 7919) % 100) / 130,
      });
    }

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      canvas.width = Math.max(1, Math.round(width * dpr));
      canvas.height = Math.max(1, Math.round(height * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const draw = (time: number) => {
      const t = time * 0.001;
      ctx.clearRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;
      const R = Math.min(width, height) * 0.335;

      // ambient glow
      const glow = ctx.createRadialGradient(cx, cy, R * 0.1, cx, cy, R * 1.9);
      glow.addColorStop(0, "rgba(14,107,77,0.13)");
      glow.addColorStop(0.45, "rgba(93,67,184,0.09)");
      glow.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, width, height);

      // particle sphere
      const rotY = t * 0.24;
      const rotX = Math.sin(t * 0.18) * 0.4 + 0.42;
      const cosY = Math.cos(rotY);
      const sinY = Math.sin(rotY);
      const cosX = Math.cos(rotX);
      const sinX = Math.sin(rotX);
      const wobble = 1 + Math.sin(t * 1.4) * 0.018;
      const fov = 3.1;

      for (const p of points) {
        const x1 = p.x * cosY + p.z * sinY;
        const z1 = -p.x * sinY + p.z * cosY;
        const y2 = p.y * cosX - z1 * sinX;
        const z2 = p.y * sinX + z1 * cosX;

        const scale = fov / (fov - z2);
        const px = cx + x1 * R * scale * wobble;
        const py = cy + y2 * R * scale * wobble;
        const depth = (z2 + 1) / 2; // 0 back -> 1 front

        ctx.beginPath();
        ctx.arc(px, py, p.size * scale * 0.85, 0, Math.PI * 2);
        ctx.fillStyle = colorAt(p.hue, 0.1 + depth * 0.62);
        ctx.fill();
      }

      // audio waveform rings
      const rings = 2;
      for (let ring = 0; ring < rings; ring++) {
        const baseR = R * (1.14 + ring * 0.13);
        const bars = 96 - ring * 24;
        for (let i = 0; i < bars; i++) {
          const angle = (i / bars) * Math.PI * 2 + t * (ring ? -0.1 : 0.16);
          const wave =
            Math.sin(t * 2.2 + i * 0.62) * Math.sin(t * 1.3 + i * 0.23 + ring * 2);
          const len = R * 0.055 * (0.4 + 0.6 * Math.abs(wave)) + 2;
          const x1 = cx + Math.cos(angle) * baseR;
          const y1 = cy + Math.sin(angle) * baseR;
          const x2 = cx + Math.cos(angle) * (baseR + len);
          const y2 = cy + Math.sin(angle) * (baseR + len);
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.lineWidth = 1.6;
          ctx.lineCap = "round";
          ctx.strokeStyle = colorAt(
            (i / bars + ring * 0.35) % 1,
            0.14 + Math.abs(wave) * 0.5,
          );
          ctx.stroke();
        }
      }

      if (!reduced && running) {
        raf = requestAnimationFrame(draw);
      }
    };

    const onVisibility = () => {
      running = document.visibilityState === "visible";
      cancelAnimationFrame(raf);
      if (running && !reduced) raf = requestAnimationFrame(draw);
    };

    resize();
    if (reduced) {
      draw(900);
    } else {
      raf = requestAnimationFrame(draw);
    }

    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      observer.disconnect();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      role="img"
      aria-label="Абстрактная анимированная визуализация звуковой сферы"
    />
  );
}

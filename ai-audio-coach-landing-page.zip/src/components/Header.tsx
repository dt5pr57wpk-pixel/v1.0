"use client";

import { useEffect, useState } from "react";
import { ArrowUpRight, AudioWaveform, Menu, X } from "lucide-react";

const LINKS = [
  { href: "#features", label: "Возможности" },
  { href: "#how", label: "Как работает" },
  { href: "#demo", label: "Демо" },
  { href: "#report", label: "Отчёт" },
  { href: "#faq", label: "FAQ" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled || open
          ? "border-b border-ink/10 bg-paper/85 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <div className="wrap flex h-[76px] items-center justify-between gap-6">
        <a
          href="#top"
          className="group flex items-center gap-3"
          aria-label="AI Audio Coach — на главную"
          onClick={() => setOpen(false)}
        >
          <span className="grid size-10 place-items-center rounded-xl bg-gradient-to-br from-pine to-teal text-cream shadow-[0_8px_22px_rgba(14,107,77,0.3)] transition-transform duration-500 group-hover:rotate-12">
            <AudioWaveform className="size-5" strokeWidth={2.4} />
          </span>
          <span className="font-display text-[0.82rem] font-bold leading-[1.15] tracking-tight">
            AI AUDIO
            <span className="block text-pine">COACH</span>
          </span>
        </a>

        <nav
          className="hidden items-center gap-7 text-sm font-medium text-umber lg:flex"
          aria-label="Основная навигация"
        >
          {LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="group relative transition-colors duration-300 hover:text-ink"
            >
              {link.label}
              <span className="absolute -bottom-1.5 left-0 h-px w-0 bg-gradient-to-r from-pine to-teal transition-all duration-400 group-hover:w-full" />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#demo"
            className="btn-shine group hidden items-center gap-2 rounded-full bg-ink px-5 py-2.5 text-sm font-bold text-cream transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_12px_32px_rgba(27,23,18,0.28)] sm:inline-flex"
          >
            Попробовать демо
            <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:rotate-45" />
          </a>
          <button
            type="button"
            className="grid size-10 place-items-center rounded-full border border-ink/15 bg-white/60 text-ink lg:hidden"
            aria-label={open ? "Закрыть меню" : "Открыть меню"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>

      <div
        className={`grid overflow-hidden transition-all duration-500 lg:hidden ${
          open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
        }`}
      >
        <div className="min-h-0">
          <nav
            className="wrap flex flex-col gap-1 border-t border-ink/10 pb-6 pt-3"
            aria-label="Мобильная навигация"
          >
            {LINKS.map((link, i) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="flex items-center justify-between rounded-xl px-3 py-3.5 font-display text-sm font-semibold text-ink transition-colors hover:bg-ink/5"
              >
                {link.label}
                <span className="text-xs font-normal text-faint">0{i + 1}</span>
              </a>
            ))}
            <a
              href="#demo"
              onClick={() => setOpen(false)}
              className="mt-3 inline-flex items-center justify-center gap-2 rounded-full bg-ink px-5 py-3.5 text-sm font-bold text-cream"
            >
              Попробовать демо
              <ArrowUpRight className="size-4" />
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}

import { ArrowUpRight, Check, Music2 } from "lucide-react";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";

const SERVICES = [
  {
    name: "Spotify",
    tagline: "Твои треки — в такт тренировке",
    accent: "bg-[#1DB954]",
    accentText: "text-[#137a3a]",
    accentBg: "bg-[#1DB954]/10",
    bullets: [
      "Экспорт готового сценария в плейлист автоматически",
      "Подбор твоих любимых треков под BPM каждой фазы",
      "Голос коуча звучит поверх музыки — без пауз и переключений",
    ],
    tracks: [
      { title: "Sunrise Flow", bpm: 102, time: "3:12" },
      { title: "Midnight Pulse", bpm: 128, time: "3:48" },
      { title: "Slow Rivers", bpm: 88, time: "4:05" },
    ],
  },
  {
    name: "Яндекс Музыка",
    tagline: "Волна подбирает, коуч направляет",
    accent: "bg-[#FC3F1D]",
    accentText: "text-[#c22f14]",
    accentBg: "bg-[#FC3F1D]/10",
    bullets: [
      "Импорт лайкнутых треков и плейлиста «Моя волна»",
      "Подбор по энергии и жанру, включая русскоязычную музыку",
      "Синергия с Yandex SpeechKit для естественного голоса коуча",
    ],
    tracks: [
      { title: "Утренний бег", bpm: 105, time: "2:58" },
      { title: "Нейон Сити", bpm: 126, time: "3:33" },
      { title: "Тихий шторм", bpm: 84, time: "4:21" },
    ],
  },
];

export default function Integrations() {
  return (
    <section id="integrations" className="relative py-24 md:py-28">
      <div className="wrap">
        <SectionHead
          num="06"
          kicker="Интеграции"
          title={
            <>
              Работает с <span className="gradient-text">твоей музыкой</span>
            </>
          }
          sub="Сценарий подключается к сервисам, где уже живут твои плейлисты. Интеграции появятся в полной версии после MVP."
        />

        <div className="mt-12 grid gap-5 lg:grid-cols-2">
          {SERVICES.map((service, index) => (
            <Reveal key={service.name} delay={index * 120}>
              <article className="card group h-full rounded-[30px] p-7 md:p-9">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <span
                      className={`grid size-12 place-items-center rounded-2xl text-white shadow-[0_10px_26px_rgba(27,23,18,0.2)] transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110 ${service.accent}`}
                    >
                      {service.name === "Spotify" ? (
                        <svg
                          viewBox="0 0 24 24"
                          className="size-6"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          aria-hidden="true"
                        >
                          <path d="M5.5 9.2c4.2-1.3 8.8-1 13 .9" />
                          <path d="M6.2 12.6c3.4-1 7.2-.8 10.6.7" />
                          <path d="M7 15.7c2.6-.7 5.5-.6 8 .5" />
                        </svg>
                      ) : (
                        <Music2 className="size-6" />
                      )}
                    </span>
                    <div>
                      <h3 className="font-display text-lg font-bold leading-tight">
                        {service.name}
                      </h3>
                      <p className="text-[0.8rem] text-umber">{service.tagline}</p>
                    </div>
                  </div>
                  <span className="rounded-full border border-ink/12 bg-white/60 px-3.5 py-1.5 text-[0.7rem] font-bold uppercase tracking-wider text-umber">
                    В разработке
                  </span>
                </div>

                <ul className="mt-7 space-y-3">
                  {service.bullets.map((bullet) => (
                    <li key={bullet} className="flex items-start gap-3 text-sm leading-relaxed text-umber">
                      <span
                        className={`mt-0.5 grid size-5 shrink-0 place-items-center rounded-full ${service.accentBg} ${service.accentText}`}
                      >
                        <Check className="size-3" strokeWidth={3} />
                      </span>
                      {bullet}
                    </li>
                  ))}
                </ul>

                {/* mock synced playlist */}
                <div className="mt-8 rounded-2xl border border-ink/10 bg-white/50 p-2.5">
                  <p className="px-2.5 pb-1.5 pt-1 text-[0.68rem] font-bold uppercase tracking-[0.18em] text-faint">
                    Так выглядит синхронизация
                  </p>
                  {service.tracks.map((track, i) => (
                    <div
                      key={track.title}
                      className="flex items-center gap-3.5 rounded-xl px-2.5 py-2.5 transition-colors hover:bg-ink/[0.045]"
                    >
                      <span className="font-mono text-xs text-faint">
                        0{i + 1}
                      </span>
                      <span
                        className={`grid size-8 place-items-center rounded-lg ${service.accentBg} ${service.accentText}`}
                      >
                        <Music2 className="size-4" />
                      </span>
                      <span className="flex-1 truncate text-sm font-semibold">
                        {track.title}
                      </span>
                      <span className="font-mono text-[0.72rem] font-semibold text-pine">
                        {track.bpm} BPM
                      </span>
                      <span className="font-mono text-[0.72rem] text-faint">
                        {track.time}
                      </span>
                    </div>
                  ))}
                </div>

                <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-bold text-ink/60">
                  Подключение появится после MVP
                  <ArrowUpRight className="size-4" />
                </span>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

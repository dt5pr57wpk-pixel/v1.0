"use client";

import { useState, type CSSProperties } from "react";
import {
  BookOpen,
  CalendarCheck,
  Check,
  Flame,
  Gauge,
  Mic,
  Music,
  Sparkles,
  ThumbsDown,
  ThumbsUp,
  Timer,
  type LucideIcon,
} from "lucide-react";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";

const STATS = [
  { icon: Timer, value: "30:00", label: "длительность" },
  { icon: CalendarCheck, value: "4 / 4", label: "фаз пройдено" },
  { icon: Gauge, value: "112", label: "средний BPM" },
  { icon: Flame, value: "~310", label: "ккал" },
];

const PHASE_BARS = [
  { name: "Разминка", pct: 100, cls: "grad-warm" },
  { name: "Активация", pct: 100, cls: "grad-fire" },
  { name: "Основная часть", pct: 96, cls: "grad-main" },
  { name: "Заминка", pct: 88, cls: "grad-cool" },
];

const RECOMMENDATIONS = [
  "В следующий раз добавь 2 минуты к основной фазе — темп держался уверенно.",
  "Попробуй треки на 128–132 BPM: на этой отметке твой ритм был максимально ровным.",
  "Не забудь про воду: цель — 300–500 мл до и после тренировки.",
];

interface FeedbackItem {
  key: string;
  label: string;
  icon: LucideIcon;
}

const FEEDBACK_ITEMS: FeedbackItem[] = [
  { key: "track", label: "Треки", icon: Music },
  { key: "facts", label: "Факты", icon: BookOpen },
  { key: "voice", label: "Голос", icon: Mic },
];

type Vote = "up" | "down" | null;

// BPM curve: smoothed polyline across the 4 phases (warmup / activation /
// main / cooldown).
const CURVE_POINTS = [
  [0, 70], [20, 62], [45, 55], [70, 48], [95, 40], [120, 30],
  [150, 22], [185, 26], [215, 34], [245, 48], [270, 58], [300, 66], [320, 70],
];
const CURVE_PATH = CURVE_POINTS.map(([x, y], i) =>
  i === 0 ? `M ${x} ${y}` : `L ${x} ${y}`,
).join(" ");
const AREA_PATH = `${CURVE_PATH} L 320 110 L 0 110 Z`;

export default function Report() {
  const [votes, setVotes] = useState<Record<string, Vote>>({});

  const votedCount = Object.values(votes).filter(Boolean).length;

  function vote(key: string, value: Exclude<Vote, null>) {
    setVotes((prev) => ({
      ...prev,
      [key]: prev[key] === value ? null : value,
    }));
  }

  return (
    <section id="report" className="relative overflow-hidden py-24 md:py-28">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(800px_460px_at_88%_12%,rgba(14,107,77,0.07),transparent_60%)]"
      />
      <div className="wrap relative">
        <SectionHead
          num="07"
          kicker="Отчёт после тренировки"
          title={
            <>
              Каждая тренировка делает{" "}
              <span className="gradient-text">следующую лучше</span>
            </>
          }
          sub="После finisша коуч собирает отчёт: длительность, пройденные фазы, темп и персональные рекомендации. Вот пример."
        />

        <div className="mt-12 grid gap-5 lg:grid-cols-[1.05fr_0.95fr]">
          {/* ---------- main report card ---------- */}
          <Reveal>
            <article className="card h-full rounded-[30px] p-7 md:p-9">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-ink/10 pb-6">
                <div>
                  <p className="text-[0.7rem] font-bold uppercase tracking-[0.2em] text-faint">
                    Воскресенье · утренняя тренировка
                  </p>
                  <h3 className="mt-2 font-display text-xl font-bold">
                    Выносливость · 30 минут
                  </h3>
                </div>
                <span className="inline-flex items-center gap-2 rounded-full border border-pine/35 bg-pine/[0.08] px-3.5 py-2 text-[0.72rem] font-bold text-pine">
                  <span className="halo-dot size-1.5 rounded-full bg-pine" />
                  Завершена на 100%
                </span>
              </div>

              <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
                {STATS.map((stat) => (
                  <div
                    key={stat.label}
                    className="rounded-2xl border border-ink/10 bg-white/60 p-4"
                  >
                    <stat.icon className="size-4.5 text-pine" />
                    <p className="mt-3 font-display text-lg font-bold leading-none">
                      {stat.value}
                    </p>
                    <p className="mt-1.5 text-[0.72rem] text-umber">
                      {stat.label}
                    </p>
                  </div>
                ))}
              </div>

              <div className="mt-8 space-y-5">
                {PHASE_BARS.map((phase, index) => (
                  <Reveal key={phase.name} delay={index * 90}>
                    <div className="flex items-baseline justify-between gap-4">
                      <span className="text-sm font-semibold">{phase.name}</span>
                      <span className="font-mono text-xs text-umber">
                        {phase.pct}%
                      </span>
                    </div>
                    <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-ink/[0.07]">
                      <div
                        className={`bar-fill h-full rounded-full ${phase.cls}`}
                        style={{ "--w": `${phase.pct}%` } as CSSProperties}
                      />
                    </div>
                  </Reveal>
                ))}
              </div>
            </article>
          </Reveal>

          <div className="grid gap-5">
            {/* ---------- BPM curve ---------- */}
            <Reveal delay={100}>
              <article className="card rounded-[30px] p-7">
                <div className="flex items-baseline justify-between gap-4">
                  <h3 className="font-display text-[0.95rem] font-bold">
                    Кривая темпа
                  </h3>
                  <span className="font-mono text-xs text-umber">
                    средний <b className="text-pine">112 BPM</b>
                  </span>
                </div>
                <svg
                  viewBox="0 0 320 110"
                  className="mt-5 w-full"
                  role="img"
                  aria-label="График изменения BPM по фазам тренировки"
                >
                  <defs>
                    <linearGradient id="bpmArea" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#0e6b4d" stopOpacity="0.28" />
                      <stop offset="100%" stopColor="#0e6b4d" stopOpacity="0" />
                    </linearGradient>
                    <linearGradient id="bpmLine" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#0e6b4d" />
                      <stop offset="55%" stopColor="#5d43b8" />
                      <stop offset="100%" stopColor="#0f6e84" />
                    </linearGradient>
                  </defs>
                  {[30, 55, 80].map((y) => (
                    <line
                      key={y}
                      x1="0"
                      x2="320"
                      y1={y}
                      y2={y}
                      stroke="#1b1712"
                      strokeOpacity="0.07"
                      strokeDasharray="3 5"
                    />
                  ))}
                  <path d={AREA_PATH} fill="url(#bpmArea)" />
                  <path
                    d={CURVE_PATH}
                    fill="none"
                    stroke="url(#bpmLine)"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  {CURVE_POINTS.filter((_, i) => i % 3 === 0).map(([x, y]) => (
                    <circle key={`${x}-${y}`} cx={x} cy={y} r="3" fill="#fefcf6" stroke="#0e6b4d" strokeWidth="2" />
                  ))}
                </svg>
                <div className="mt-2 flex justify-between font-mono text-[0.66rem] text-faint">
                  <span>0 мин</span>
                  <span>разминка</span>
                  <span>основная</span>
                  <span>заминка</span>
                  <span>30 мин</span>
                </div>
              </article>
            </Reveal>

            {/* ---------- recommendations ---------- */}
            <Reveal delay={170}>
              <article className="card rounded-[30px] p-7">
                <h3 className="flex items-center gap-2.5 font-display text-[0.95rem] font-bold">
                  <Sparkles className="size-4.5 text-pine" />
                  Рекомендации коуча
                </h3>
                <ul className="mt-5 space-y-3.5">
                  {RECOMMENDATIONS.map((rec) => (
                    <li key={rec} className="flex items-start gap-3 text-sm leading-relaxed text-umber">
                      <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-pine/10 text-pine">
                        <Check className="size-3" strokeWidth={3} />
                      </span>
                      {rec}
                    </li>
                  ))}
                </ul>
              </article>
            </Reveal>

            {/* ---------- feedback ---------- */}
            <Reveal delay={240}>
              <article className="card rounded-[30px] p-7">
                <h3 className="font-display text-[0.95rem] font-bold">
                  Оцени тренировку
                </h3>
                <p className="mt-1.5 text-[0.8rem] text-umber">
                  Оценка улучшает подбор трека, фактов и голоса.
                </p>
                <div className="mt-5 grid gap-2.5">
                  {FEEDBACK_ITEMS.map((item) => {
                    const current = votes[item.key] ?? null;
                    return (
                      <div
                        key={item.key}
                        className="flex items-center justify-between gap-4 rounded-2xl border border-ink/10 bg-white/60 px-4 py-3"
                      >
                        <span className="flex items-center gap-2.5 text-sm font-semibold">
                          <item.icon className="size-4 text-pine" />
                          {item.label}
                        </span>
                        <span className="flex gap-2">
                          <button
                            type="button"
                            aria-label={`${item.label}: нравится`}
                            aria-pressed={current === "up"}
                            onClick={() => vote(item.key, "up")}
                            className={`grid size-9 place-items-center rounded-full border transition-all duration-300 ${
                              current === "up"
                                ? "border-pine bg-pine text-cream shadow-[0_6px_18px_rgba(14,107,77,0.35)]"
                                : "border-ink/15 bg-white/70 text-umber hover:border-pine/50 hover:text-pine"
                            }`}
                          >
                            <ThumbsUp className="size-4" />
                          </button>
                          <button
                            type="button"
                            aria-label={`${item.label}: не нравится`}
                            aria-pressed={current === "down"}
                            onClick={() => vote(item.key, "down")}
                            className={`grid size-9 place-items-center rounded-full border transition-all duration-300 ${
                              current === "down"
                                ? "border-ink bg-ink text-cream"
                                : "border-ink/15 bg-white/70 text-umber hover:border-ink/40 hover:text-ink"
                            }`}
                          >
                            <ThumbsDown className="size-4" />
                          </button>
                        </span>
                      </div>
                    );
                  })}
                </div>
                <p
                  className={`mt-4 text-[0.8rem] font-semibold text-pine transition-opacity duration-500 ${
                    votedCount > 0 ? "opacity-100" : "opacity-0"
                  }`}
                  role="status"
                >
                  Спасибо! Это улучшит твой следующий сценарий.
                </p>
              </article>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

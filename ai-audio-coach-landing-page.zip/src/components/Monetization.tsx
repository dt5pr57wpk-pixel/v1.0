import { Building2, Crown, Handshake, Mic, type LucideIcon } from "lucide-react";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";

interface MoneyCard {
  icon: LucideIcon;
  title: string;
  text: string;
  accent: string;
}

const CARDS: MoneyCard[] = [
  {
    icon: Crown,
    title: "Подписка",
    text: "Премиум-сценарии и персонализация · ориентир 299–499 ₽/мес.",
    accent: "text-pine bg-pine/10",
  },
  {
    icon: Mic,
    title: "Кастомные голоса",
    text: "Уникальные голоса, стили и пакеты коучинга.",
    accent: "text-grape bg-grape/10",
  },
  {
    icon: Building2,
    title: "B2B для фитнес-залов",
    text: "Брендированные аудиотренировки для клубов.",
    accent: "text-teal bg-teal/10",
  },
  {
    icon: Handshake,
    title: "Партнёрские программы",
    text: "Коллаборации с брендами, авторами и продуктами.",
    accent: "text-ember bg-ember/10",
  },
];

export default function Monetization() {
  return (
    <section id="monetization" className="relative py-24 md:py-28">
      <div className="wrap">
        <SectionHead
          num="09"
          kicker="Монетизация"
          title={
            <>
              Несколько <span className="gradient-text">источников роста</span>
            </>
          }
          sub="Гибкая модель для пользователей и партнёров."
        />

        <div className="mt-12 grid gap-3.5 sm:grid-cols-2 xl:grid-cols-4">
          {CARDS.map((card, index) => (
            <Reveal key={card.title} delay={index * 70}>
              <article className="card group h-full rounded-3xl p-6">
                <span
                  className={`grid size-12 place-items-center rounded-2xl transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110 ${card.accent}`}
                >
                  <card.icon className="size-5.5" strokeWidth={1.9} />
                </span>
                <h3 className="mt-6 font-display text-[0.95rem] font-semibold">
                  {card.title}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-umber">
                  {card.text}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

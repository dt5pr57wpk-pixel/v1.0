import {
  BarChart3,
  BookOpen,
  Brain,
  HeartPulse,
  Mic,
  Music,
  ThumbsUp,
  User,
  type LucideIcon,
} from "lucide-react";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";

interface Feature {
  icon: LucideIcon;
  title: string;
  text: string;
}

const FEATURES: Feature[] = [
  { icon: User, title: "Профиль пользователя", text: "Цели, уровень подготовки, ограничения и любимые жанры." },
  { icon: Brain, title: "Генератор тренировки", text: "ИИ создаёт структуру по фазам и выбранной длительности." },
  { icon: Music, title: "Музыкальный движок", text: "Подбор треков по BPM, энергии и музыкальному жанру." },
  { icon: Mic, title: "Голосовой коуч", text: "TTS-озвучка фактов, мотивации и подсказок по технике." },
  { icon: BookOpen, title: "Контент-банк", text: "Проверенные факты, мифы и советы по фитнесу." },
  { icon: HeartPulse, title: "Адаптация", text: "Потенциальная подстройка под пульс, самочувствие и поведение." },
  { icon: ThumbsUp, title: "Обратная связь", text: "Лайк или дизлайк треков, фактов и голоса для улучшения подбора." },
  { icon: BarChart3, title: "Отчёт после тренировки", text: "Длительность, пройденные фазы и рекомендации на будущее." },
];

const TILE_STYLES = [
  "bg-pine/10 text-pine",
  "bg-grape/10 text-grape",
  "bg-teal/10 text-teal",
];

export default function Features() {
  return (
    <section id="features" className="relative py-24 md:py-28">
      <div className="wrap">
        <SectionHead
          num="01"
          kicker="Возможности"
          title={
            <>
              Всё, что нужно для эффективной{" "}
              <span className="gradient-text">тренировки</span>
            </>
          }
          sub="Персонализация, музыка и полезные подсказки — в одном аудиосценарии."
        />

        <div className="mt-12 grid gap-3.5 sm:grid-cols-2 xl:grid-cols-4">
          {FEATURES.map((feature, index) => (
            <Reveal key={feature.title} delay={(index % 4) * 70}>
              <article className="card group h-full rounded-3xl p-6">
                <div className="flex items-start justify-between">
                  <span
                    className={`grid size-12 place-items-center rounded-2xl transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110 ${
                      TILE_STYLES[index % 3]
                    }`}
                  >
                    <feature.icon className="size-5.5" strokeWidth={1.9} />
                  </span>
                  <span className="font-display text-xs font-semibold text-faint/80 transition-colors duration-300 group-hover:text-pine/70">
                    0{index + 1}
                  </span>
                </div>
                <h3 className="mt-6 font-display text-[0.95rem] font-semibold leading-snug">
                  {feature.title}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-umber">
                  {feature.text}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

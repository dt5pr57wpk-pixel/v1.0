import {
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

export const workouts = pgTable("workouts", {
  id: uuid("id").primaryKey().defaultRandom(),
  goal: text("goal").notNull(),
  durationMinutes: integer("duration_minutes").notNull(),
  level: text("level").notNull(),
  genres: text("genres").array().notNull(),
  voice: text("voice").notNull(),
  coachIntervalMinutes: integer("coach_interval_minutes").notNull(),
  scenario: jsonb("scenario").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Workout = typeof workouts.$inferSelect;
export type NewWorkout = typeof workouts.$inferInsert;

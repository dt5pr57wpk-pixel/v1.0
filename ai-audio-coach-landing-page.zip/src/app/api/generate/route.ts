import { db } from "@/db";
import { workouts } from "@/db/schema";
import { buildScenario, validateScenarioInput } from "@/lib/scenario";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Некорректный запрос." }, { status: 400 });
  }

  const parsed = validateScenarioInput(body);

  if (!parsed.ok) {
    return Response.json({ error: parsed.error }, { status: 422 });
  }

  const scenario = buildScenario(parsed.data);

  try {
    const [row] = await db
      .insert(workouts)
      .values({
        goal: parsed.data.goal,
        durationMinutes: parsed.data.duration,
        level: parsed.data.level,
        genres: parsed.data.genres,
        voice: parsed.data.voice,
        coachIntervalMinutes: parsed.data.frequency,
        scenario,
      })
      .returning({ id: workouts.id });

    const serial = await db.$count(workouts);

    return Response.json({
      scenario,
      id: row.id,
      serial,
      persisted: true,
    });
  } catch (error) {
    // The demo must stay useful even if the database is unavailable.
    console.error("[generate] failed to persist workout:", error);
    return Response.json({
      scenario,
      id: null,
      serial: null,
      persisted: false,
    });
  }
}

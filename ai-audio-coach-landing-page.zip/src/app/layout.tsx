import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Unbounded, Manrope } from "next/font/google";
import "./globals.css";

const unbounded = Unbounded({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-unbounded",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-manrope",
  display: "swap",
});

export const metadata: Metadata = {
  title: "AI Audio Coach — персональный аудиотренер с ИИ",
  description:
    "Музыка + голосовой коуч. Без камер, тренажёров и сложного оборудования — только телефон и наушники. Интеграция со Spotify и Яндекс Музыкой.",
};

export const viewport: Viewport = {
  themeColor: "#f4eee2",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className={`${unbounded.variable} ${manrope.variable}`}>
      <body className="bg-paper font-body text-ink antialiased">
        {children}
        <div aria-hidden="true" className="grain" />
      </body>
    </html>
  );
}

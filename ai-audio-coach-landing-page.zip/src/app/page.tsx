import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import Features from "@/components/Features";
import Steps from "@/components/Steps";
import Phases from "@/components/Phases";
import Demo from "@/components/Demo";
import Integrations from "@/components/Integrations";
import Report from "@/components/Report";
import Faq from "@/components/Faq";
import Monetization from "@/components/Monetization";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Marquee />
        <Features />
        <Steps />
        <Phases />
        <Demo />
        <Integrations />
        <Report />
        <Faq />
        <Monetization />
      </main>
      <Footer />
    </>
  );
}

// Shared workout-scenario logic. Used by the API route (server) and by the
// demo UI (client) for types and constants — keep this file free of
// server-only imports.

export const GOALS = [
  "Похудение",
  "Сила",
  "Выносливость",
  "Восстановление",
  "Общая форма",
] as const;

export const DURATIONS = [20, 30, 45, 60] as const;

export const LEVELS = ["Новичок", "Средний", "Продвинутый"] as const;

export const GENRES = ["Pop", "Rock", "Electronic", "Hip-hop", "Chill"] as const;

export const VOICES = [
  "Женский, энергичный",
  "Мужской, энергичный",
  "Женский, спокойный",
  "Мужской, спокойный",
] as const;

export const FREQUENCIES = [2, 5, 10] as const;

export interface ScenarioInput {
  goal: string;
  duration: number;
  level: string;
  genres: string[];
  voice: string;
  frequency: number;
}

export type PhaseKey = "warmup" | "activation" | "main" | "cooldown";

export interface Phase {
  key: PhaseKey;
  name: string;
  start: number;
  end: number;
  minutes: number;
  bpm: [number, number];
  tone: string;
  cue: string;
}

export interface WorkoutScenario extends ScenarioInput {
  app: string;
  generatedAt: string;
  mode: "prototype";
  note: string;
  phases: Phase[];
}

export type ValidationResult =
  | { ok: true; data: ScenarioInput }
  | { ok: false; error: string };

export function validateScenarioInput(body: unknown): ValidationResult {
  if (typeof body !== "object" || body === null) {
    return { ok: false, error: "Некорректное тело запроса." };
  }

  const raw = body as Record<string, unknown>;

  const goal = typeof raw.goal === "string" ? raw.goal : "";
  const level = typeof raw.level === "string" ? raw.level : "";
  const voice = typeof raw.voice === "string" ? raw.voice : "";
  const duration = Number(raw.duration);
  const frequency = Number(raw.frequency);
  const genres = Array.isArray(raw.genres)
    ? raw.genres.filter(
        (g): g is string =>
          typeof g === "string" && (GENRES as readonly string[]).includes(g),
      )
    : [];

  if (!(GOALS as readonly string[]).includes(goal)) {
    return { ok: false, error: "Выбери цель тренировки." };
  }
  if (!(DURATIONS as readonly number[]).includes(duration)) {
    return { ok: false, error: "Выбери длительность тренировки." };
  }
  if (!(LEVELS as readonly string[]).includes(level)) {
    return { ok: false, error: "Выбери уровень подготовки." };
  }
  if (genres.length === 0) {
    return { ok: false, error: "Выбери хотя бы один музыкальный жанр." };
  }
  if (!(VOICES as readonly string[]).includes(voice)) {
    return { ok: false, error: "Выбери голос коуча." };
  }
  if (!(FREQUENCIES as readonly number[]).includes(frequency)) {
    return { ok: false, error: "Выбери частоту подсказок." };
  }

  return {
    ok: true,
    data: { goal, duration, level, genres, voice, frequency },
  };
}

const PHASE_META: Array<{ key: PhaseKey; name: string; tone: string }> = [
  { key: "warmup", name: "Разминка", tone: "Спокойный тон" },
  { key: "activation", name: "Активация", tone: "Мотивация" },
  { key: "main", name: "Основная часть", tone: "Факты и энергия" },
  { key: "cooldown", name: "Заминка", tone: "Расслабление" },
];

const SHARES = [0.17, 0.17, 0.5, 0.16];

export function buildPhases(
  totalMinutes: number,
  goal: string,
  level: string,
  frequency: number,
): Phase[] {
  const bpms: Array<[number, number]> =
    goal === "Восстановление"
      ? [
          [80, 95],
          [90, 105],
          [95, 115],
          [70, 85],
        ]
      : level === "Продвинутый"
        ? [
            [95, 110],
            [115, 125],
            [130, 150],
            [80, 95],
          ]
        : [
            [90, 110],
            [110, 120],
            [120, 140],
            [80, 90],
          ];

  const cues = [
    `Начинаем мягко. Найди комфортное дыхание и постепенно включайся в движение. Подсказки — примерно каждые ${frequency} мин.`,
    "Постепенно добавляй темп, сохраняя контроль движений. Не спеши — качественный разогрев важнее скорости.",
    goal === "Сила"
      ? "Сосредоточься на технике и контролируемом усилии. Качество движения важнее количества повторений."
      : goal === "Восстановление"
        ? "Сохраняй лёгкую интенсивность. Расслабь плечи, дыши ровно и держи комфортный ритм."
        : "Ты уже в ритме! Держи устойчивый темп, пей воду и прислушивайся к своему телу.",
    "Плавно снижаем интенсивность. Восстанови дыхание и заверши занятие лёгкой растяжкой — без боли и рывков.",
  ];

  const minutes = SHARES.map((share) => Math.floor(totalMinutes * share));
  minutes[2] += totalMinutes - minutes.reduce((sum, m) => sum + m, 0);

  let cursor = 0;

  return PHASE_META.map((meta, index) => {
    const start = cursor;
    cursor += minutes[index];
    return {
      key: meta.key,
      name: meta.name,
      start,
      end: cursor,
      minutes: minutes[index],
      bpm: bpms[index],
      tone: meta.tone,
      cue: cues[index],
    };
  });
}

export function buildScenario(input: ScenarioInput): WorkoutScenario {
  return {
    app: "AI Audio Coach",
    mode: "prototype",
    generatedAt: new Date().toISOString(),
    note: "Сценарий собран прототипом. В полной версии музыка и голос микшируются в единый аудиофайл.",
    ...input,
    phases: buildPhases(
      input.duration,
      input.goal,
      input.level,
      input.frequency,
    ),
  };
}
